package filesprocessing.filters;

/**
 * Exception class, for errors in filter string format
 */
public class FilterException extends Exception
{
    /*-----=  static fields  =-----*/

    private static final long serialVersionUID = 1L;
}
