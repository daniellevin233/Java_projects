package filesprocessing.orders;

/**
 * Exception class, for errors in order string format
 */
public class OrderException extends Exception
{
    /*-----=  static fields  =-----*/

    private static final long serialVersionUID = 1L;
}
